# Question 11: call1.py Module
def add1(x, y):
    return x + y

def sub1(x, y):
    return x - y

def mul1(x, y):
    return x * y

def div1(x, y):
    if y != 0:
        return x / y
    else:
        return "Division by zero not allowed"

def mod1(x, y):
    if y != 0:
        return x % y
    else:
        return "Modulo by zero not allowed"

def pow1(x, y):
    return x ** y
