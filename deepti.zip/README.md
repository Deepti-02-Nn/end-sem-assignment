# GitHub Assignment Submission

This repository contains solutions for Questions 1-12 for Python error handling and modules.
