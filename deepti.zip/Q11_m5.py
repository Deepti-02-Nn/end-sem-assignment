# Question 11: m5.py Using call1
import call1

print("Addition:", call1.add1(10, 5))
print("Subtraction:", call1.sub1(10, 5))
print("Multiplication:", call1.mul1(10, 5))
print("Division:", call1.div1(10, 5))
print("Modulo:", call1.mod1(10, 5))
print("Power:", call1.pow1(2, 3))
